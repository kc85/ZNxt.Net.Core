--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2 (Debian 13.2-1.pgdg100+1)
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE identity;
--
-- Name: identity; Type: DATABASE; Schema: -; Owner: root
--

CREATE DATABASE identity WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.utf8';


ALTER DATABASE identity OWNER TO root;

\connect identity

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: group; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."group" (
    group_id bigint NOT NULL,
    name text,
    description text,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL,
    tenant_id bigint
);


ALTER TABLE public."group" OWNER TO root;

--
-- Name: group_group_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public."group" ALTER COLUMN group_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.group_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: group_permission; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.group_permission (
    group_permission_id bigint NOT NULL,
    permission_id bigint NOT NULL,
    group_id bigint NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.group_permission OWNER TO root;

--
-- Name: group_permission_group_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.group_permission ALTER COLUMN group_permission_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.group_permission_group_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: oauth_client; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.oauth_client (
    oauth_client_id bigint NOT NULL,
    client_id text,
    description text,
    client_secret text,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL,
    tenant_id bigint,
    salt text
);


ALTER TABLE public.oauth_client OWNER TO root;

--
-- Name: oauth_client_oauth_client_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.oauth_client ALTER COLUMN oauth_client_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.oauth_client_oauth_client_id_seq
    START WITH 1111111
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: oauth_client_role; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.oauth_client_role (
    oauth_client_role_id bigint NOT NULL,
    oauth_client_id bigint NOT NULL,
    role_id bigint NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.oauth_client_role OWNER TO root;

--
-- Name: oauth_client_role_oauth_client_role_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.oauth_client_role ALTER COLUMN oauth_client_role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.oauth_client_role_oauth_client_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permission; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.permission (
    permission_id bigint NOT NULL,
    name text,
    description text,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.permission OWNER TO root;

--
-- Name: permission_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.permission ALTER COLUMN permission_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.permission_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: permission_role; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.permission_role (
    permission_role_id bigint NOT NULL,
    permission_id bigint NOT NULL,
    role_id bigint NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.permission_role OWNER TO root;

--
-- Name: permission_role_permission_role_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.permission_role ALTER COLUMN permission_role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.permission_role_permission_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: role; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.role (
    role_id bigint NOT NULL,
    name text,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.role OWNER TO root;

--
-- Name: role_role_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.role ALTER COLUMN role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.role_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public."user" (
    user_id bigint NOT NULL,
    user_name character(50) NOT NULL,
    email text,
    first_name text NOT NULL,
    middle_name text,
    last_name text,
    salt text,
    is_enabled boolean NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    user_auth_type_id bigint NOT NULL
);


ALTER TABLE public."user" OWNER TO root;

--
-- Name: user_auth_type; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_auth_type (
    user_auth_type_id bigint NOT NULL,
    name text,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.user_auth_type OWNER TO root;

--
-- Name: user_auth_type_user_auth_type_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_auth_type ALTER COLUMN user_auth_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_auth_type_user_auth_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_group; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_group (
    user_group_id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id bigint NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.user_group OWNER TO root;

--
-- Name: user_group_user_group_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_group ALTER COLUMN user_group_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_group_user_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_login_fail_lock; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_login_fail_lock (
    user_login_fail_lock_id bigint NOT NULL,
    user_id bigint,
    count bigint,
    is_locked boolean NOT NULL,
    note text,
    lock_start_time bigint,
    lock_end_time bigint,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    lock_type bigint
);


ALTER TABLE public.user_login_fail_lock OWNER TO root;

--
-- Name: user_login_fail_lock_user_login_fail_lock_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_login_fail_lock ALTER COLUMN user_login_fail_lock_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_login_fail_lock_user_login_fail_lock_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_login_history; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_login_history (
    user_login_history_id bigint NOT NULL,
    user_id bigint,
    created_on bigint,
    note text,
    is_success boolean NOT NULL
);


ALTER TABLE public.user_login_history OWNER TO root;

--
-- Name: user_login_history_user_login_history_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_login_history ALTER COLUMN user_login_history_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_login_history_user_login_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_password; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_password (
    user_pass_id bigint NOT NULL,
    user_id bigint,
    password text NOT NULL,
    is_enabled boolean NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text
);


ALTER TABLE public.user_password OWNER TO root;

--
-- Name: user_password_user_pass_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_password ALTER COLUMN user_pass_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_password_user_pass_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_profile; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_profile (
    user_profile_id bigint NOT NULL,
    user_id bigint,
    phone_number text,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text
);


ALTER TABLE public.user_profile OWNER TO root;

--
-- Name: user_profile_user_profile_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_profile ALTER COLUMN user_profile_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_profile_user_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_role; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_role (
    user_role_id bigint NOT NULL,
    user_id bigint,
    is_enabled boolean NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    role_id bigint
);


ALTER TABLE public.user_role OWNER TO root;

--
-- Name: user_role_user_role_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_role ALTER COLUMN user_role_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_role_user_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_tenant; Type: TABLE; Schema: public; Owner: root
--

CREATE TABLE public.user_tenant (
    user_tenant_id bigint NOT NULL,
    user_id bigint NOT NULL,
    tenant_id bigint NOT NULL,
    created_on bigint,
    updated_on bigint,
    updated_by text,
    created_by text,
    is_enabled boolean NOT NULL
);


ALTER TABLE public.user_tenant OWNER TO root;

--
-- Name: user_tenant_user_tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public.user_tenant ALTER COLUMN user_tenant_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_tenant_user_tenant_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: user_user_id_seq; Type: SEQUENCE; Schema: public; Owner: root
--

ALTER TABLE public."user" ALTER COLUMN user_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.user_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: group; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."group" (group_id, name, description, created_on, updated_on, updated_by, created_by, is_enabled, tenant_id) FROM stdin;
\.
COPY public."group" (group_id, name, description, created_on, updated_on, updated_by, created_by, is_enabled, tenant_id) FROM '$$PATH$$/3112.dat';

--
-- Data for Name: group_permission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.group_permission (group_permission_id, permission_id, group_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.group_permission (group_permission_id, permission_id, group_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3118.dat';

--
-- Data for Name: oauth_client; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.oauth_client (oauth_client_id, client_id, description, client_secret, created_on, updated_on, updated_by, created_by, is_enabled, tenant_id, salt) FROM stdin;
\.
COPY public.oauth_client (oauth_client_id, client_id, description, client_secret, created_on, updated_on, updated_by, created_by, is_enabled, tenant_id, salt) FROM '$$PATH$$/3122.dat';

--
-- Data for Name: oauth_client_role; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.oauth_client_role (oauth_client_role_id, oauth_client_id, role_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.oauth_client_role (oauth_client_role_id, oauth_client_id, role_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3124.dat';

--
-- Data for Name: permission; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.permission (permission_id, name, description, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.permission (permission_id, name, description, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3114.dat';

--
-- Data for Name: permission_role; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.permission_role (permission_role_id, permission_id, role_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.permission_role (permission_role_id, permission_id, role_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3120.dat';

--
-- Data for Name: role; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.role (role_id, name, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.role (role_id, name, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3101.dat';

--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public."user" (user_id, user_name, email, first_name, middle_name, last_name, salt, is_enabled, created_on, updated_on, updated_by, created_by, user_auth_type_id) FROM stdin;
\.
COPY public."user" (user_id, user_name, email, first_name, middle_name, last_name, salt, is_enabled, created_on, updated_on, updated_by, created_by, user_auth_type_id) FROM '$$PATH$$/3095.dat';

--
-- Data for Name: user_auth_type; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_auth_type (user_auth_type_id, name, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.user_auth_type (user_auth_type_id, name, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3104.dat';

--
-- Data for Name: user_group; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_group (user_group_id, user_id, group_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.user_group (user_group_id, user_id, group_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3116.dat';

--
-- Data for Name: user_login_fail_lock; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_login_fail_lock (user_login_fail_lock_id, user_id, count, is_locked, note, lock_start_time, lock_end_time, created_on, updated_on, updated_by, created_by, lock_type) FROM stdin;
\.
COPY public.user_login_fail_lock (user_login_fail_lock_id, user_id, count, is_locked, note, lock_start_time, lock_end_time, created_on, updated_on, updated_by, created_by, lock_type) FROM '$$PATH$$/3100.dat';

--
-- Data for Name: user_login_history; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_login_history (user_login_history_id, user_id, created_on, note, is_success) FROM stdin;
\.
COPY public.user_login_history (user_login_history_id, user_id, created_on, note, is_success) FROM '$$PATH$$/3099.dat';

--
-- Data for Name: user_password; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_password (user_pass_id, user_id, password, is_enabled, created_on, updated_on, updated_by, created_by) FROM stdin;
\.
COPY public.user_password (user_pass_id, user_id, password, is_enabled, created_on, updated_on, updated_by, created_by) FROM '$$PATH$$/3098.dat';

--
-- Data for Name: user_profile; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_profile (user_profile_id, user_id, phone_number, created_on, updated_on, updated_by, created_by) FROM stdin;
\.
COPY public.user_profile (user_profile_id, user_id, phone_number, created_on, updated_on, updated_by, created_by) FROM '$$PATH$$/3096.dat';

--
-- Data for Name: user_role; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_role (user_role_id, user_id, is_enabled, created_on, updated_on, updated_by, created_by, role_id) FROM stdin;
\.
COPY public.user_role (user_role_id, user_id, is_enabled, created_on, updated_on, updated_by, created_by, role_id) FROM '$$PATH$$/3097.dat';

--
-- Data for Name: user_tenant; Type: TABLE DATA; Schema: public; Owner: root
--

COPY public.user_tenant (user_tenant_id, user_id, tenant_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM stdin;
\.
COPY public.user_tenant (user_tenant_id, user_id, tenant_id, created_on, updated_on, updated_by, created_by, is_enabled) FROM '$$PATH$$/3126.dat';

--
-- Name: group_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.group_group_id_seq', 2, true);


--
-- Name: group_permission_group_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.group_permission_group_permission_id_seq', 2, true);


--
-- Name: oauth_client_oauth_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.oauth_client_oauth_client_id_seq', 1111113, true);


--
-- Name: oauth_client_role_oauth_client_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.oauth_client_role_oauth_client_role_id_seq', 7, true);


--
-- Name: permission_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.permission_permission_id_seq', 2, true);


--
-- Name: permission_role_permission_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.permission_role_permission_role_id_seq', 3, true);


--
-- Name: role_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.role_role_id_seq', 42, true);


--
-- Name: user_auth_type_user_auth_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_auth_type_user_auth_type_id_seq', 8, true);


--
-- Name: user_group_user_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_group_user_group_id_seq', 2, true);


--
-- Name: user_login_fail_lock_user_login_fail_lock_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_login_fail_lock_user_login_fail_lock_id_seq', 9, true);


--
-- Name: user_login_history_user_login_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_login_history_user_login_history_id_seq', 1, true);


--
-- Name: user_password_user_pass_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_password_user_pass_id_seq', 4, true);


--
-- Name: user_profile_user_profile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_profile_user_profile_id_seq', 23, true);


--
-- Name: user_role_user_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_role_user_role_id_seq', 73, true);


--
-- Name: user_tenant_user_tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_tenant_user_tenant_id_seq', 1, true);


--
-- Name: user_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: root
--

SELECT pg_catalog.setval('public.user_user_id_seq', 26, true);


--
-- Name: group_permission group_permission_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.group_permission
    ADD CONSTRAINT group_permission_pk PRIMARY KEY (group_permission_id);


--
-- Name: group group_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."group"
    ADD CONSTRAINT group_pk PRIMARY KEY (group_id);


--
-- Name: oauth_client oauth_client_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.oauth_client
    ADD CONSTRAINT oauth_client_pk PRIMARY KEY (oauth_client_id);


--
-- Name: oauth_client_role oauth_client_role_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.oauth_client_role
    ADD CONSTRAINT oauth_client_role_pk PRIMARY KEY (oauth_client_role_id);


--
-- Name: permission permission_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission
    ADD CONSTRAINT permission_pk PRIMARY KEY (permission_id);


--
-- Name: permission_role permission_role_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_pk PRIMARY KEY (permission_role_id);


--
-- Name: role role_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.role
    ADD CONSTRAINT role_pk PRIMARY KEY (role_id);


--
-- Name: user_auth_type user_auth_type_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_auth_type
    ADD CONSTRAINT user_auth_type_pk PRIMARY KEY (user_auth_type_id);


--
-- Name: user_group user_group_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_group
    ADD CONSTRAINT user_group_pk PRIMARY KEY (user_group_id);


--
-- Name: user_login_fail_lock user_login_fail_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_login_fail_lock
    ADD CONSTRAINT user_login_fail_lock_pkey PRIMARY KEY (user_login_fail_lock_id);


--
-- Name: user_login_history user_login_history_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_login_history
    ADD CONSTRAINT user_login_history_pkey PRIMARY KEY (user_login_history_id);


--
-- Name: user_password user_pass_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_password
    ADD CONSTRAINT user_pass_pkey PRIMARY KEY (user_pass_id);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (user_id);


--
-- Name: user_profile user_profile_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_pkey PRIMARY KEY (user_profile_id);


--
-- Name: user_role user_role_pkey; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_pkey PRIMARY KEY (user_role_id);


--
-- Name: user_tenant user_tenant_id_pk; Type: CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_tenant
    ADD CONSTRAINT user_tenant_id_pk PRIMARY KEY (user_tenant_id);


--
-- Name: fki_group_permission_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_group_permission_fk ON public.group_permission USING btree (permission_id);


--
-- Name: fki_group_permission_group_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_group_permission_group_fk ON public.group_permission USING btree (group_id);


--
-- Name: fki_permission_role_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_permission_role_fk ON public.permission_role USING btree (permission_id);


--
-- Name: fki_permission_role_role_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_permission_role_role_fk ON public.permission_role USING btree (role_id);


--
-- Name: fki_use_login_hostory_user_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_use_login_hostory_user_id_fk ON public.user_login_history USING btree (user_id);


--
-- Name: fki_user_auth_type_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_auth_type_fk ON public."user" USING btree (user_auth_type_id);


--
-- Name: fki_user_login_fail_user_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_login_fail_user_id_fk ON public.user_login_fail_lock USING btree (user_id);


--
-- Name: fki_user_password_user_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_password_user_id_fk ON public.user_password USING btree (user_id);


--
-- Name: fki_user_profile_user_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_profile_user_id_fk ON public.user_profile USING btree (user_id);


--
-- Name: fki_user_role_role_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_role_role_id_fk ON public.user_role USING btree (role_id);


--
-- Name: fki_user_role_user_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_role_user_id_fk ON public.user_role USING btree (user_id);


--
-- Name: fki_user_tenant_user_id_fk; Type: INDEX; Schema: public; Owner: root
--

CREATE INDEX fki_user_tenant_user_id_fk ON public.user_tenant USING btree (user_id);


--
-- Name: group_permission group_permission_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.group_permission
    ADD CONSTRAINT group_permission_fk FOREIGN KEY (permission_id) REFERENCES public.permission(permission_id) NOT VALID;


--
-- Name: group_permission group_permission_group_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.group_permission
    ADD CONSTRAINT group_permission_group_fk FOREIGN KEY (group_id) REFERENCES public."group"(group_id) NOT VALID;


--
-- Name: permission_role permission_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_fk FOREIGN KEY (permission_id) REFERENCES public.permission(permission_id) NOT VALID;


--
-- Name: permission_role permission_role_role_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.permission_role
    ADD CONSTRAINT permission_role_role_fk FOREIGN KEY (role_id) REFERENCES public.role(role_id) NOT VALID;


--
-- Name: user_login_history use_login_hostory_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_login_history
    ADD CONSTRAINT use_login_hostory_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user user_auth_type_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_auth_type_fk FOREIGN KEY (user_auth_type_id) REFERENCES public.user_auth_type(user_auth_type_id) NOT VALID;


--
-- Name: user_login_fail_lock user_login_fail_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_login_fail_lock
    ADD CONSTRAINT user_login_fail_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user_password user_password_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_password
    ADD CONSTRAINT user_password_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user_profile user_profile_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_profile
    ADD CONSTRAINT user_profile_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user_role user_role_role_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_role_id_fk FOREIGN KEY (role_id) REFERENCES public.role(role_id) NOT VALID;


--
-- Name: user_role user_role_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_role
    ADD CONSTRAINT user_role_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- Name: user_tenant user_tenant_user_id_fk; Type: FK CONSTRAINT; Schema: public; Owner: root
--

ALTER TABLE ONLY public.user_tenant
    ADD CONSTRAINT user_tenant_user_id_fk FOREIGN KEY (user_id) REFERENCES public."user"(user_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

